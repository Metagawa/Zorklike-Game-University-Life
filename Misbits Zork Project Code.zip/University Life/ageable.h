#ifndef AGEABLE_H
#define AGEABLE_H

class Ageable {
public:
  void getOlder();
  void setAge(int age);
  int age = 0;
};

#endif // AGEABLE_H
