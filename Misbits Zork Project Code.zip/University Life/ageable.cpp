#include "ageable.h"

// increases the age
void Ageable::getOlder() { this->age++; }

// sets the current age
void Ageable::setAge(int age) { this->age = age; }
