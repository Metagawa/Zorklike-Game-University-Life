#include "nameable.h"
#include <string>
using namespace std;

// sets the name to the string name
void Nameable::setName(string name) { this->name = name; }
