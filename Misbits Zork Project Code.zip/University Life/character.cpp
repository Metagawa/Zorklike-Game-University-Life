#include "character.h"
#include <string>
using namespace std;

void Character::levelUp() { getOlder(); }
