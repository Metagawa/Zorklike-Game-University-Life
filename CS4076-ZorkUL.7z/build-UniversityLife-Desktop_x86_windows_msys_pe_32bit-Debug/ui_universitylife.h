/********************************************************************************
** Form generated from reading UI file 'universitylife.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_UNIVERSITYLIFE_H
#define UI_UNIVERSITYLIFE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Zork
{
public:
    QWidget *centralwidget;
    QLabel *imageBackground;
    QPlainTextEdit *plainTextEdit;
    QLineEdit *lineEdit;
    QWidget *widget;
    QGridLayout *gridLayout;
    QPushButton *putButton;
    QPushButton *eastButton;
    QPushButton *infoButton;
    QPushButton *quitButton;
    QPushButton *southButton;
    QPushButton *mapButton;
    QPushButton *westButton;
    QPushButton *takeButton;
    QPushButton *northButton;

    void setupUi(QMainWindow *Zork)
    {
        if (Zork->objectName().isEmpty())
            Zork->setObjectName(QString::fromUtf8("Zork"));
        Zork->resize(846, 547);
        QFont font;
        font.setFamily(QString::fromUtf8("MV Boli"));
        Zork->setFont(font);
        centralwidget = new QWidget(Zork);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        imageBackground = new QLabel(centralwidget);
        imageBackground->setObjectName(QString::fromUtf8("imageBackground"));
        imageBackground->setEnabled(true);
        imageBackground->setGeometry(QRect(490, 10, 350, 240));
        imageBackground->setMaximumSize(QSize(350, 240));
        imageBackground->setLayoutDirection(Qt::LeftToRight);
        imageBackground->setAutoFillBackground(false);
        imageBackground->setPixmap(QPixmap(QString::fromUtf8(":/new/images/images/gym-room.png")));
        imageBackground->setScaledContents(true);
        imageBackground->setAlignment(Qt::AlignHCenter|Qt::AlignTop);
        imageBackground->setWordWrap(false);
        imageBackground->setIndent(0);
        plainTextEdit = new QPlainTextEdit(centralwidget);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));
        plainTextEdit->setGeometry(QRect(9, 9, 471, 491));
        QFont font1;
        font1.setFamily(QString::fromUtf8("MV Boli"));
        font1.setPointSize(12);
        plainTextEdit->setFont(font1);
        plainTextEdit->setReadOnly(true);
        plainTextEdit->setOverwriteMode(false);
        lineEdit = new QLineEdit(centralwidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(10, 510, 471, 31));
        widget = new QWidget(centralwidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(490, 430, 351, 111));
        gridLayout = new QGridLayout(widget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        putButton = new QPushButton(widget);
        putButton->setObjectName(QString::fromUtf8("putButton"));
        putButton->setFont(font1);

        gridLayout->addWidget(putButton, 0, 0, 1, 1);

        eastButton = new QPushButton(widget);
        eastButton->setObjectName(QString::fromUtf8("eastButton"));
        eastButton->setFont(font1);

        gridLayout->addWidget(eastButton, 1, 2, 1, 1);

        infoButton = new QPushButton(widget);
        infoButton->setObjectName(QString::fromUtf8("infoButton"));
        infoButton->setFont(font1);

        gridLayout->addWidget(infoButton, 2, 0, 1, 1);

        quitButton = new QPushButton(widget);
        quitButton->setObjectName(QString::fromUtf8("quitButton"));
        quitButton->setFont(font1);

        gridLayout->addWidget(quitButton, 2, 2, 1, 1);

        southButton = new QPushButton(widget);
        southButton->setObjectName(QString::fromUtf8("southButton"));
        southButton->setFont(font1);

        gridLayout->addWidget(southButton, 2, 1, 1, 1);

        mapButton = new QPushButton(widget);
        mapButton->setObjectName(QString::fromUtf8("mapButton"));
        mapButton->setFont(font1);

        gridLayout->addWidget(mapButton, 1, 1, 1, 1);

        westButton = new QPushButton(widget);
        westButton->setObjectName(QString::fromUtf8("westButton"));
        westButton->setFont(font1);

        gridLayout->addWidget(westButton, 1, 0, 1, 1);

        takeButton = new QPushButton(widget);
        takeButton->setObjectName(QString::fromUtf8("takeButton"));
        takeButton->setFont(font1);

        gridLayout->addWidget(takeButton, 0, 2, 1, 1);

        northButton = new QPushButton(widget);
        northButton->setObjectName(QString::fromUtf8("northButton"));
        northButton->setFont(font1);

        gridLayout->addWidget(northButton, 0, 1, 1, 1);

        Zork->setCentralWidget(centralwidget);

        retranslateUi(Zork);

        QMetaObject::connectSlotsByName(Zork);
    } // setupUi

    void retranslateUi(QMainWindow *Zork)
    {
        Zork->setWindowTitle(QCoreApplication::translate("Zork", "Zork", nullptr));
        imageBackground->setText(QString());
        putButton->setText(QCoreApplication::translate("Zork", "Put", nullptr));
        eastButton->setText(QCoreApplication::translate("Zork", "East", nullptr));
        infoButton->setText(QCoreApplication::translate("Zork", "Info", nullptr));
        quitButton->setText(QCoreApplication::translate("Zork", "Quit", nullptr));
        southButton->setText(QCoreApplication::translate("Zork", "South", nullptr));
        mapButton->setText(QCoreApplication::translate("Zork", "Map", nullptr));
        westButton->setText(QCoreApplication::translate("Zork", "West", nullptr));
        takeButton->setText(QCoreApplication::translate("Zork", "Take", nullptr));
        northButton->setText(QCoreApplication::translate("Zork", "North", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Zork: public Ui_Zork {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UNIVERSITYLIFE_H
